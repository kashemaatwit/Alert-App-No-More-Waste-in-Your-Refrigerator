package edu.wit.mobileappdevelopment.seniorproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);

        for (int i = 0; i < 10; i++){
            adapter.add("item " + i);
        }

        ListView list = findViewById(R.id.ItemList);
        list.setAdapter(adapter);

        Button addButton = findViewById(R.id.Add);
        Button filterButton = findViewById(R.id.Filter);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addIntent = new Intent();
                addIntent.setClass(MainActivity.this, Add.class);

                startActivity(addIntent);
            }
        });

        filterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent filterIntent = new Intent();
                filterIntent.setClass(MainActivity.this, Filter.class);

                startActivity(filterIntent);
            }
        });
    }
}